# T-012 · 契约指纹 + 最小 kernel 自检

| 项 | 值 |
|---|---|
| 优先级 | P2 |
| 预估 | 4 h |
| 依赖 | T-000 |
| 需要真机 | 建议 |
| 对应分析 | [07-ops-config.md](../07-ops-config.md) O2、[02-build-contract.md](../02-build-contract.md) 结论 |

## 要解决的两个具体问题

### 1. 「这一轮跑的到底是哪一版模板？」没人知道

本次事故里出现过：`src/package-files.ts` 改了，但 `build_test_package` 仍渲染旧写法；
模型只好**每轮手工修补渲染产物**。三类文件的生效边界各不相同，且没有指纹可查：

| 改动位置 | 生效时机 |
|---|---|
| `templates/build-contract/*` | 下一次 `build_test_package`（每次从盘读） |
| `remote/runner.py` | 下一次 `run_evaluation`（每次上传） |
| `src/**.ts` → `lib/**.js` | **需重启 dsh / 重载插件** |

**要做**：`build_test_package` 返回并写入 `manifest.json`：

```json
{
  "contract": {
    "schemaVersion": "v1",
    "templatesMtime": "2026-11-06T15:46:12+08:00",
    "libHash": "sha256:...",
    "pluginVersion": "0.2.0"
  }
}
```

`run_evaluation` 上传前比对本地产物 hash 与 manifest，不一致直接报错
（防止「包被手工改过」的静默漂移）。

### 2. 模板坏了，却以「模型写错」的面目出现

C2（`static_cast<GM_ADDR>`）和 C3（重复符号）都是**任何算子都编译不过**的模板缺陷，
但在闭环里表现为「模型的代码有问题」，白白消耗 `maxCompileRetries`。

**要做**：`build_test_package` 前置生成一个**最小 kernel**（只做 `DataCopy` 到输出的三行代码），
渲染 + 编译（不上传、不评测），失败就立刻报「契约模板本身坏了：<错误>」。

> 如果本地没有编译器，可以做成可选的 `contractSelfCheck: true` 配置，
> 或者只在远端跑：把最小 kernel 随包上传，`runner.py` 在正式编译前先编一次它。

## 验收

- [ ] `manifest.json` 含 `contract` 三个字段
- [ ] 手工改一个渲染产物后 `run_evaluation` 报错（而不是静默上传）
- [ ] 故意把模板改坏（例如把 `(GM_ADDR)` 改回 `static_cast`），`build_test_package` 当场失败
