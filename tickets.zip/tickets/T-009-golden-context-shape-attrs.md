# T-009 · golden 拿得到 shape / attrs

| 项 | 值 |
|---|---|
| 优先级 | P2 |
| 预估 | 4 h |
| 依赖 | 无 |
| 需要真机 | **是**（一次编译即可） |
| 对应分析 | [04-accuracy-contract.md](../04-accuracy-contract.md) A2 |

## 现象

契约里 golden 的唯一签名：

```cpp
float evaluate(int out, const float* const* in, int in_count, int64_t index);
```

没有 rank / shape / strides，没有算子属性（ArgMax 的 `dim`、`keepdim`），返回值只能是 float。
本次 ArgMax 的 golden 只能把形状写死：

```cpp
constexpr int32_t kArgMaxLen = 2048;   // 只对 dim=-1、last dim=2048 成立
```

**spec 换成 `[2048,4096]` 或 `dim=0`，golden 会静默算错而不是报错** —— 这是最危险的一类缺陷：
它不会崩，只会给你一个错误但看起来合理的 `badCount = 0`。

## 要做的事

1. 升级信号（保留旧签名的兼容分支，避免既有包全挂）：

```cpp
struct GoldenCtx {
    const int64_t* shape;   // 输入 0 的 shape
    int32_t rank;
    int64_t attr_dim;       // 由 spec.attrs 透传
    int32_t attr_keepdim;
};
float evaluate(GoldenCtx ctx, int out, const float* const* in, int in_count, int64_t index);
```

2. `OperatorSpec` 增加 `attrs: Record<string, number | boolean | string>`，
   由 `package-files.ts` 渲染成 `canness_tiling.h` 里的常量或构造函数参数字面量；
3. `golden.h` 模板里提供 **shape 断言宏**，让模型写死的形状能被显式检查：

```cpp
CANNESS_REQUIRE_SHAPE(rank == 2 && shape[1] == 2048);
```

   不满足时 golden 返回 `NaN` 或显式失败，而不是静默算错；
4. 文档里说明：`attrs` 是透传字段，契约不解释语义。

## 测试

```ts
// 1) spec 带 attrs 时，渲染出的 canness_tiling.h / golden.h 含对应常量
// 2) 形状断言宏在 shape 不匹配时产生编译期/运行期错误
```

## 验收（真机）

- [ ] 用 `[2048,4096]` 的 spec 跑一次：golden 里的断言**报错**，而不是给出 `badCount=0`
- [ ] 用 `[2048,2048]` 的 spec 跑一次：正常
