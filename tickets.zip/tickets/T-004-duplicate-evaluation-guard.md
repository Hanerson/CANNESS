# T-004 · 同包去重，重复评测不计迭代

| 项 | 值 |
|---|---|
| 优先级 | P1 |
| 预估 | 3~4 h |
| 依赖 | T-002（共用 `pendingSteer` 机制） |
| 需要真机 | 否 |

## 现象

那 11 轮里至少有 5 轮是**同一份代码重测**：

```
668.293 → 668.293   （同构建复测）
349.627 → 349.627   （无改动复测）
```

每次都消耗一次远端评测（12~14 s）、一次上传、一次注入，
但**不携带任何新信息**。

## 要做的事

1. `build_test_package` 计算包内容 hash（四层文件 + `golden.h` + `manifest.json` 的规范化摘要），
   写进 `state.json` 的 `packageHash`，也写进上传的 `manifest.json`；
2. `run_evaluation` 开头比较：当前包 hash 与 `state.lastEvaluatedHash` 相同 →
   **不连接远端**，直接返回上一份报告，并打标：

   ```json
   { "status": "error", "duplicate": true, "summary": "duplicate package: same content as the last evaluation" }
   ```

   或者更友好：返回上次报告的副本 + `duplicate: true`，**不增加 `validIterations`、不置 `pendingSteer`**；
3. 允许显式绕过：`run_evaluation` 增加参数 `force: true`（用于怀疑测量抖动的复测），
   但绕过时要在 `runRecord.params` 里记录 `forced: true`。

## 设计要点

- 返回「上次报告」而不是 error，是为了让模型知道**当前结果是什么**，而不是误以为出错；
- `duplicate` 必须**可见**（tool 输出里明确），否则模型会以为评测失败而改代码；
- 与 T-002 配合：去重命中时不置 `pendingSteer`，循环自然停下。

## 测试

```ts
// a) 同包第二次 → duplicate:true，validIterations 不变，不 steer
// b) 改了 kernel.cpp → hash 变，正常评测
// c) force:true → 正常评测，runRecord.params.forced === true
// d) hash 计算对文件顺序 / 换行符稳定（同一包两次渲染 hash 相同）
```

## 验收

- [ ] 4 条单测
- [ ] 手工：连续两次 `build_test_package` + `run_evaluation`，第二次不产生远端流量
      （可用远端 `ls -l --time-style=full-iso` 观察 inbox 目录 mtime 未变）
