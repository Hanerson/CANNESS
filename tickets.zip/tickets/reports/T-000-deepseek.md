# T-000 完成报告

- 认领人：DeepSeek Harness（agent）
- 分支 / PR：`main`（直接提交，未开 PR）
- 提交：
  - `187850d` fix(contract): render C-style GM_ADDR casts, carry launch geometry
  - `eeac773` fix(runner): find the msprof CSV below PROF_*/, never guess a bottleneck
  - `a72c078` feat(policy): stall detection, budget carry-over, condensed log injection
  - `72c93e0` chore: ignore Python bytecode from the remote runner
  - `d8695f1` fix(loop): drive one retry per report, and only in the session that owns it
    （这条属于 T-001/T-002，同批推送，记录在此便于对照）
- 开始 / 完成：2026-11-06 16:51 / 16:56
- 远端：`origin/main` = `d8695f1`，工作区 0 项未提交

## 做了什么

1. 把工作区那 11 个文件按语义拆成 3 个功能提交（契约 / runner / policy+知识库），
   另加 `.gitignore` 提交；
2. 删除 `plugin/remote/__pycache__/` 并加入忽略；
3. `npm run build` 重建 `lib/`；
4. `knowledge_base/ArgMax.md` 随 policy 提交一起入库（内容未改动，仅核对编码：UTF-8，59 行）。

## 验证记录

### 构建产物 marker（`npm run build` 之后）

```
lib\spec.js              launch         OK
lib\policy.js            isStalled      OK
lib\generator.js         carriedOver    OK
lib\eval.js              stallRounds    OK
lib\loop.js              ownsSession    OK
lib\package-files.js     (GM_ADDR)      OK
```

### 单元测试

```
$ npx vitest run
Test Files  1 failed | 19 passed (20)
     Tests  7 failed | 152 passed (159)
```

失败全部在 `tests/eval-runner.test.ts`（7/8），**与本批改动无关**：

- 症状：`bash: .../gen-fixture001/build.sh: No such file or directory`
  （Windows 下 Git Bash 的路径解析）；
- 对照实验：把全部改动 `git stash` 后重跑，失败数仍是 7 —— 与 ticket 描述一致；
- 处理方案见 T-013。

### 一致性

- `grep "static_cast<GM_ADDR>" plugin/src plugin/lib` 无输出；
- `git status` 干净。

## 遗留问题 / 与 ticket 描述不符的地方

1. **ticket 里写的「四个 marker」不够**：实际需要六个
   （`loop.stallRounds` 与 `package-files.(GM_ADDR)` 也要查）。已在上面的清单里补齐。
2. **`lib/` 不入库**（`.gitignore` 忽略），「产物要不要入库」这个约定问题仍然悬着。
   T-014 里建议的「生效边界表」必须写明：**改完 src 必须 build，build 完必须重启 dsh**。
3. **提交 `187850d` 里含 issue 003 的临时方案**（`--allow-multiple-definition`），
   彻底方案在 T-011，届时需要删掉它并验证。

## 对其它 ticket 的影响

- T-001 / T-002 已基于本提交后的 `policy.ts` / `loop.ts` 完成（见各自报告与 `d8695f1`）；
- T-005 的部分内容（stall + 预算）已在 `a72c078` 里，仍需补 `generator` 的 4 条测试；
- T-011 需要回头删掉 `187850d` 里的链接器放宽。
