# T-002 完成报告

- 认领人：DeepSeek Harness（agent）
- 分支：`main`
- 提交：与 T-001 同一个提交（改动同一批文件）
- 完成：2026-11-06 16:55

## 做了什么

1. `policy.ts`：`TaskState` 增加 `pendingSteer?: boolean`，`emptyState()` 置 `false`。
2. `eval.ts`：`run_evaluation` 写出报告时置 `pendingSteer: true`（每份报告欠一次续轮）。
   - **早退路径不置位**：host 为空、凭据缺失、CANNLab 隧道断开、连接失败、策略停机
     —— 这些是「失败」而不是「有结果要跟进」，不应该自我驱动。
3. `generator.ts`：`submit_spec` 换代时置 `false`（新包还没评测，什么都不欠）。
4. `loop.ts`：
   - `steerable()` 要求 `pendingSteer === true`；
   - **先消费再注入 / 再 steer**（`saveState({...state, pendingSteer: false})`），
     保证一份报告只换一次续轮；
   - 注入路径仍然保留「同一段文本已在本轮出现就不重复塞」的第二道保险。

## 为什么这样就断了自持回路

原来：`turn-stopping` 只看「上次报告不是 pass」→ 每轮结束都 steer → 新回合 → 再 steer……

现在：一次评测 → `pendingSteer=true` → 回合开始时注入一次并消费 → 模型工作 →
回合结束 `turn-stopping` 发现 `pendingSteer=false` → 不再 steer。
**下一个回合只可能由「新的评测」或「用户」产生。**

## 验证记录

`tests/plugins.test.ts` 覆盖：

| 场景 | 期望 | 结果 |
|---|---|---|
| `pendingSteer=true` + 归属匹配 | 注入 1 条，之后 `pendingSteer` 变 false | ✅ |
| 紧接着再触发 pre-step | 0 条（已消费） | ✅ |
| `pendingSteer=false` + `lastReport=perf_fail` | 0 条 | ✅ |
| `turn-stopping` 连续两次 | 只 steer 一次 | ✅ |
| 新报告到达 | 重新 steer 一次（共 2 次） | ✅ |

```
$ npx vitest run tests/plugins.test.ts
Tests  22 passed (22)
```

## 遗留问题

1. 与 T-001 一样：**真实会话的注入次数未实测**（本机 canness 已停用）。
2. `pendingSteer` 没有 TTL：如果一次报告后用户离开很久，回来后第一次回合仍会收到那条提示。
   这符合「欠一次」的语义，但如果你觉得应该过期（例如 30 分钟），可以并到 T-003 一起做。
3. 与 T-004（同包去重）配合时要注意：去重命中**不应**置 `pendingSteer`，
   否则「重复评测」又会被当成新信息引发续轮。T-004 的 ticket 里已写明。

## 复查建议

这条改动影响所有会话的自动续轮行为，建议合并后观察一次真实任务：
跑一次 `run_evaluation` 后不发言，确认只被驱动**一次**而不是每 5 秒一次。
