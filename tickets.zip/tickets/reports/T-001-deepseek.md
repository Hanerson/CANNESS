# T-001 完成报告

- 认领人：DeepSeek Harness（agent）
- 分支：`main`
- 提交：`<下一步统一提交>`（与 T-002 同一个提交，两者改动同一批文件）
- 完成：2026-11-06 16:55

## 做了什么

1. `policy.ts`
   - `TaskState` 增加 `ownerSessionId?: string | null`，`emptyState()` 置 `null`；
   - 新增 `ownsSession(state, sessionId)`：只有当记录存在且**相等**时返回 true。
2. `eval.ts`
   - `run_evaluation` 的 `execute(_args, exec?)` 读取 `exec.agent.session.id`；
   - 写出报告时写 `ownerSessionId: owner ?? state.ownerSessionId ?? null`
     —— 后一次调用会**接管**任务，不会出现两个会话同时认为自己拥有。
3. `generator.ts`
   - `submit_spec` 换代时保留 `ownerSessionId`，避免换代把任务「弄丢」而让循环对该会话彻底静音。
4. `loop.ts`
   - 两个监听器共用一个 `steerable(payload)` 守卫，先判归属；
   - `agent/pre-step` 与 `agent/turn-stopping` 都从 payload 里取 `agent.session.id`。

## 行为变更（需要写进 CHANGELOG）

**升级后，老任务的 `state.json` 没有 `ownerSessionId`，循环不会再自动续跑。**
这是有意的：不去猜测归属，就不会再出现「另一个会话被催」的问题。
用户需要在该会话里跑一次 `run_evaluation` 重新认领。

## 验证记录

`tests/plugins.test.ts`：

```
✓ pre-step appends a retry only when an evaluation owes one and this session owns it
✓ turn-stopping steers once per owed retry, and only for the owning session
✓ run_evaluation claims the task for the calling session and owes exactly one retry
```

覆盖的分支：

| 场景 | 期望 | 结果 |
|---|---|---|
| 归属匹配 + 欠一次 + 策略允许 | 注入 1 条 | ✅ |
| 归属不匹配 | 注入 0 条，且不消费欠账 | ✅ |
| 无 `ownerSessionId`（旧文件） | 注入 0 条 | ✅ |
| 会话 B 跑 `run_evaluation` | 归属被 B 接管 | ✅ |

## 遗留问题

1. **没有做端到端的双会话手工验证**（ticket 验收里那条「会话 B 什么都不做 5 分钟 → 0 次注入」）。
   本机当前已停用 canness，且我不想在没有你确认的情况下重新加载插件去跑真人会话。
   单测已覆盖该逻辑，但**真实注入次数仍未经实测**。
2. 归属只认 `session.id`，没有处理「会话被 fork」的情况：fork 出来的新会话不拥有旧任务。
   如果以后需要，再单独提 ticket。

## 对其它 ticket 的影响

- T-002 与本 ticket 共用 `steerable()` 守卫，已被后续提交覆盖；
- T-003（限流）可以直接挂在同一个守卫上，改动很小。
