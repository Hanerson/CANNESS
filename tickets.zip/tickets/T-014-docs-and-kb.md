# T-014 · 文档与知识库收尾

| 项 | 值 |
|---|---|
| 优先级 | P2 |
| 预估 | 3 h |
| 依赖 | T-000（知识库文件在保留分支里） |
| 需要真机 | 否 |

## 三件事

### 1. 知识库补 ArgMax（文件已写好，只需审阅）

`plugin/knowledge_base/ArgMax.md`（59 行，在 `origin/preserve/2026-11-06-argmax-run` 分支）已包含：

- 契约要点（入口签名、int64→F32 的坑、`launch` 字段用法）；
- 实测数据（349.6µs / blockDim 曲线 / 厂商基线）；
- 语义坑清单。

**请审阅内容是否正确**，然后随 T-000 一起入库。

### 2. 把「repeat 上限 64」写进知识库（原 issue 015，尚无条目）

`WholeReduce*` 单次 `repeatTimes` 实测安全上限是 **64**，超过后：

- 编译、链接、运行都**不报错**；
- 结果**静默错**（本次 128 repeat 时，每个 tile 的第 4 行恒错，`bad=512/2048`）；
- 拆成两次 64 仍错，说明还有「同一 LocalTensor 既作上一调用 src、又作下一调用 dst」的别名问题
  → 需要 `PipeBarrier<PIPE_V>()` 或换缓冲。

请写进 `knowledge_base/AscendC_Compile_Run.md` 或新建条目。

### 3. 文档补「生效边界」与「如何验证」

`plugin/README.md` §5 现在只写了「改完源码必须重新 build」，**没写 build 了还要重载进程**。
请补一张表：

| 改动位置 | 生效时机 | 备注 |
|---|---|---|
| `templates/build-contract/*` | 下一次 `build_test_package` | 每次从盘读 |
| `remote/runner.py` | 下一次 `run_evaluation` | 每次上传 |
| `src/**.ts` / `lib/**.js` | **需重启 dsh** | `lib/` 是运行期加载的产物 |
| `knowledge_base/*` | 下次 `kb_search` | 从盘读 |

并在根 README 的「已知限制」里加一条：
**评测循环的自动续轮是 per-profile 行为，升级前请阅读 loop 相关 CHANGELOG。**

## 验收

- [ ] `kb_search("ArgMax")` 能命中
- [ ] `kb_search("WholeReduce")` 能命中 repeat 上限条目
- [ ] `plugin/README.md` 里有上面那张表
- [ ] CHANGELOG 记录了 T-001/T-002 的行为变更
