# T-013 · 修 Windows 下 `eval-runner.test.ts` 的 7 条失败

| 项 | 值 |
|---|---|
| 优先级 | P3 |
| 预估 | 2~4 h |
| 依赖 | 无 |
| 需要真机 | 否 |

## 现状（先确认这不是你弄坏的）

```
$ npx vitest run tests/eval-runner.test.ts
Test Files  1 failed (1)
     Tests  7 failed | 1 passed (8)
```

我做过对照实验：**把工作区改动全部 stash 掉，失败数仍是 7**。
所以这是既有环境问题，不是某次改动引入的。

## 症状

失败了的那条测试的 `compile.log`：

```
bash: C:/Users/71575/AppData/Local/Temp/canness-runner-XXXX/inbox/gen-fixture001/build.sh:
      No such file or directory
```

测试用 `cpSync(fixture, pkg, { recursive: true })` 把
`tests/fixtures/eval-contract/` 拷到临时目录，再让 `bash build.sh` 去执行。
在 Windows 下 `bash` 解析到了别的东西（WSL 的 launcher 或 Git Bash 的路径映射），
导致 `/c/...` 与 `/mnt/c/...` 不一致，路径找不到。

文件确实被拷过去了（同一个 fixture 里 `manifest.json`、`config.json` 都在），
所以问题在「**路径在 bash 里的表示**」，不在拷贝。

## 排查方向

1. 在测试里打印 `bash -c 'echo $PWD'` 与 `cygpath -m <path>`，确认实际工作目录；
2. `eval-runner.test.ts` 里已有 `bashCommand()`（注释写着「Windows resolves bash to WSL's launcher
   from System32; the fixture needs Git Bash」）——看它是否真的选中了 Git Bash；
3. 若用 Git Bash，把临时目录转成 `/c/Users/...` 形式再传给它；若用 WSL，把路径转成 `/mnt/c/...`；
4. 最优解：测试里**不依赖 bash**，把 fixture 的 `build.sh` / `run_once.sh` 换成 `node` 脚本，
   或者在 Windows 上 `test.skipIf(process.platform === 'win32')` 并注明原因（最省事，但会丢覆盖率）。

## 验收

- [ ] `npx vitest run` 全绿（或明确 skip 并在 PR 描述说明）
- [ ] 改动只在 `tests/` 内，不碰产品代码

## 注意

这条**不是** P0/P1 的阻塞项，但它影响所有人跑 `pnpm test` 的信心：
每次都看到 7 条红，会让人误以为自己的改动坏了。建议排在 P2 之后、P3 之前做掉。
