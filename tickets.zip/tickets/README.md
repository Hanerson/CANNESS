# 任务分发指南（给接手的人看这一份就够）

你不需要读完全部 8 篇分析文档。按下面的顺序做：

1. 读本文件；
2. 做 **T-000**（10 分钟，不做的话后面全都会被误导）；
3. 认领你自己那条 ticket，先在 `tickets/reports/` 里拷一份模板，边做边填。

---

## 一、背景，一段话

CANNESS 是一个 dsh 插件，把「CANN 算子开发」做成闭环：模型写四层代码 → 打包 → 上传到远端 NPU 评测 → 按结果自动再来一轮。
2026-11-06 用真实 CANNLab 环境跑了一个 ArgMax 任务，结果**评测循环失控**：模型没能退出，
一个会话在 36 分钟里被注入了 232 次「请再评测一轮」，另一个会话被注入 40 次。
这次事故的全部问题已整理成 `target-issues/` 下的 8 篇文档 + 16 条原 issue 的映射。

## 二、先要知道的三个事实

### 事实 1：仓库 HEAD 是坏的

`main` 的最新提交 `dd9328d` 里，构建契约模板**仍然渲染 `static_cast<GM_ADDR>`**，
这行代码在任何 clang 基编译器上都会编译失败。也就是说：**从仓库拉下来直接跑，第一次评测必挂**。

那次任务能跑下去，是因为有人在**本地工作区**改了代码、并且**手工改过渲染产物**。
这批改动已经推到了保留分支，但**没有进 main**：

```
分支：origin/preserve/2026-11-06-argmax-run  (commit d3d0843)
内容：12 个文件，518 行新增
状态：仅存档，未经端到端验证，不要直接合并
```

### 事实 2：有一批「看起来修了其实没生效」的代码

本地工作区里 `src/` 改了，但 `lib/`（dsh 实际加载的产物）只重建了一部分：

| 模块 | 运行期是否生效 |
|---|---|
| `package-files`（GM_ADDR 强转、blockDim、workspace） | 生效 |
| `spec`（`launch.block_dim`） | **不生效** |
| `policy`（`isStalled`） | **不生效** |
| `generator`（预算继承） | **不生效** |
| `eval`（stall 配置） | **不生效** |
| `loop`（stall 配置） | **不生效** |

**这就是 T-000 要处理的事。**

### 事实 3：循环的根因不是「判据太松」，而是「没有边界」

`canness-loop` 通过 `agent/turn-stopping` 主动 steer 下一轮，而：

- 它**不区分会话**（`state.json` 只有一份，`pre-step` 传进来的 `agent` 被忽略了）；
- 它**不要求本轮真的跑过评测**（所以模型空转也会被催）；
- 它**没有去重**（同一段文本能连续注入几十次）。

所以「加一个 target_unreachable 判据」只是缓解，**T-001 / T-002 才是根治**。

## 三、铁律（违反会浪费大家的时间）

1. **`tests/eval-runner.test.ts` 现在 8 条里失败 7 条，不是你弄坏的。** 这是 Windows 下 Git Bash 的既有问题，
   与本次改动无关（拿改动 stash 掉也一样失败）。别去修它，除非你认领 T-013。
2. **`lib/` 必须和 `src/` 同步重建**：`pnpm build`。改完源码不 build，运行期仍是旧逻辑。
   改完还要**重启 dsh**（或在支持 HMR 的场景下重载插件），否则进程里还是旧模块。
3. **不要为了让指标变绿去调低 `target_us`**。那正是这次事故里循环失控的诱因之一。
4. **每个任务单独一个 PR**，并在 `reports/` 里填观测记录。PR 描述里请写清「改了什么、怎么验证的、还有什么没验证」。
5. **别把修复直接合进 main 前先描述行为变化**：loop / eval 的改动会影响所有人的会话，需要你知道自己在改什么。

## 四、依赖顺序

```
T-000 (止血基线：重建 lib + 提交语义清晰的 commit)
  │
  ├─► T-001 会话归属 ──┐
  ├─► T-002 按评测驱动 ─┴─► T-003 限流 ──► T-004 同包去重
  │                                        └─► T-010 出口工具（可选）
  │
  ├─► T-006 set_env 探测（唯一还挡着「干净镜像首轮能否编译」的 P0）
  ├─► T-011 引擎：单次 build 不再双份 TU（替代 C3 的链接器放宽）
  └─► T-012 契约自检（防止再出现「必然失败」的模板）
```

`T-005 / T-007 / T-008 / T-009` 互不依赖，可并行。

## 五、ticket 索引

| ID | 标题 | 优先级 | 预估 | 是否需要真机 |
|---|---|---|---|---|
| [T-000](T-000-restore-green-baseline.md) | 止血基线：重建 lib、把已验证改动拆成干净提交 | P0 | 2~3 h | 否 |
| [T-001](T-001-loop-session-affinity.md) | 循环加会话归属，消除跨会话串味 | **P0** | 4~6 h | 否 |
| [T-002](T-002-loop-driven-by-eval.md) | 循环只在本轮真跑过评测时驱动 | **P0** | 4~6 h | 否 |
| [T-003](T-003-loop-steer-rate-limit.md) | steer 限流（间隔 + 每报告上限） | P1 | 2 h | 否 |
| [T-004](T-004-duplicate-evaluation-guard.md) | 同包去重，重复评测不计迭代 | P1 | 3~4 h | 否 |
| [T-005](T-005-policy-stall-and-budget.md) | 停滞判据 + 预算不可被清零（代码已在保留分支） | P1 | 2~3 h | 否 |
| [T-006](T-006-setenv-probe.md) | set_env.sh 三级探测 + 进 runRecord | **P0** | 3 h | **是**（一次） |
| [T-007](T-007-analysis-truthful-bottleneck.md) | 瓶颈判据诚实化 + 带宽/roofline 字段 | P1 | 4 h | 建议 |
| [T-008](T-008-int64-output-and-accuracy-mode.md) | int64 输出与 index-check 精度模式 | P1 | 1~2 d | **是** |
| [T-009](T-009-golden-context-shape-attrs.md) | golden 拿得到 shape / attrs | P2 | 4 h | **是** |
| [T-010](T-010-sampling-runs.md) | 多次采样与热身（`over 1 rows` 问题） | P1 | 4 h | **是** |
| [T-011](T-011-build-helper-tu.md) | 单次编译，消除重复符号（去掉链接器放宽） | P2 | 4 h | **是** |
| [T-012](T-012-contract-fingerprint-selfcheck.md) | 契约指纹 + 最小 kernel 自检 | P2 | 4 h | 建议 |
| [T-013](T-013-windows-runner-tests.md) | 修 Windows 下 `eval-runner.test.ts` 的 7 条失败 | P3 | 2~4 h | 否 |
| [T-014](T-014-docs-and-kb.md) | 文档与知识库收尾（含 repeat 上限、生效边界） | P2 | 3 h | 否 |

合计约 **5~7 人日**。**只有 T-006 / T-008 / T-009 / T-010 / T-011 需要真机**，
其余全部可以在本地用单元测试验证（循环类尤其不需要 NPU）。

## 六、需要谁

| 角色 | 认领 | 说明 |
|---|---|---|
| 熟悉 dsh 插件 / Cordis 的人 | T-001、T-002、T-003 | 改动 loop 与 eval 的交互，最敏感 |
| 熟悉 AscendC / CANN 的人 | T-006、T-008、T-009、T-010、T-011 | 需要真机判断 |
| 谁都可以 | T-004、T-005、T-007、T-013、T-014 | 逻辑清晰、有测试可依 |

## 七、什么时候可以宣布「这次事故修好了」

最小验收（做完 5 条即算止血）：

1. `git status` 干净，`main` 上 `pnpm build` 后四个 marker 全部命中
   （`lib/spec.js` 有 `launch`、`lib/policy.js` 有 `isStalled`、`lib/generator.js` 有 `carriedOver`、`lib/eval.js` 有 `stallRounds`）；
2. 伪造一份 `perf_fail` 的 `state.json`，起一个会话**不发言 10 分钟** → 注入次数 **0**（现在是 5 秒一次）；
3. 同 profile 起第二个会话 → 注入次数 **0**（现在会被串味）；
4. 同包重复 `run_evaluation` → 返回 `duplicate`，`validIterations` 不变；
5. 干净 CANNLab 镜像上首轮 `run_evaluation` 不再 `exit 127`。

## 八、原始材料位置

| 内容 | 路径 |
|---|---|
| 现场快照（未验证，勿直接合并） | 分支 `origin/preserve/2026-11-06-argmax-run`（`git show d3d0843 --stat`） |
| 出事时状态文件 | `evidence/state-snapshot.json` |
| 注入统计与复现脚本 | `evidence/injection-stats.md` |
| 原 16 条 issue 映射 | `evidence/issue-index.md` |
| 详细分析 | 同级目录 `01` ~ `08` 八篇 |
