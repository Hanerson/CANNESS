# T-011 · 单次编译，消除重复符号（去掉链接器放宽）

| 项 | 值 |
|---|---|
| 优先级 | P2 |
| 预估 | 4 h |
| 依赖 | T-000（先接受 `--allow-multiple-definition` 的临时方案） |
| 需要真机 | **是** |
| 对应分析 | [02-build-contract.md](../02-build-contract.md) C3 |

## 现状

`g_tilingKey` 在 `main.o` 与 `kernel.o` 各有一份强定义，
当前用 `-Wl,--allow-multiple-definition` 绕过：

```
ld.lld: error: duplicate symbol: g_tilingKey
>>> defined at main.o:(g_tilingKey)
>>> defined at kernel.cpp
```

放宽链接器是**能跑但脆弱**的：哪天两份定义不再等价，就会出现「静默用错那一份」的问题，
而且它掩盖了「host TU 根本不需要内核头」这个真正的事实。

## 推荐方案：一次编译 + `--cce-fatobj-link`（**需先在真机验证**）

Ascend 的 ccec 支持把 host 与 device 代码放在同一个编译单元里：

```bash
"$BISHENG" --cce-aicore-arch=dav-c220 \
  -O2 -shared -fPIC --cce-fatobj-link \
  -I<tikcfw> -I<include> \
  main.cpp kernel.cpp -o libcanness.so
```

这样 host 侧只会生成 `static` 注册函数，`g_tilingKey` 只在 device 侧出现一次。

> ⚠️ 我没有在本机验证过这个组合（本次任务里没有跑到这一步）。
> 请先在真机上用最小 kernel 试：`--cce-fatobj-link` 是否可用、是否需要 `-xcce`、
> 与现有 `-include canness_tiling.h` 是否冲突。**验证通过再改模板。**

## 备选方案（更保守）

拆头文件：

```
canness_tiling_common.h   // 纯 POD 结构体，host / kernel 共用
canness_tiling_kernel.h   // 含 kernel_operator.h，只给 kernel TU
```

`build.sh` 只对 `kernel.cpp` 加 `-include`，`main.o` 不再引入内核头 → 不会重复定义。

## 验收（真机）

- [ ] 去掉 `-Wl,--allow-multiple-definition` 后仍能链接
- [ ] `nm` / `llvm-nm` 里 `g_tilingKey` 只出现一次（或为 local）
- [ ] 一次完整 `run_evaluation` 的 `badCount = 0` 且 `compile.ok = true`

## 风险

这是模板改动，影响所有包。请先用一个**最小 kernel**验证，再合并。
如果 `--cce-fatobj-link` 验证失败，就走备选方案，**不要**为了赶进度保留链接器放宽了事——把结论写进 issue 即可。
