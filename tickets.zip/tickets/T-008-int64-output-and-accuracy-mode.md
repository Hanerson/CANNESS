# T-008 · int64 输出与 index-check 精度模式

| 项 | 值 |
|---|---|
| 优先级 | P1 |
| 预估 | 1~2 天（最大的一块） |
| 依赖 | 无 |
| 需要真机 | **是** |
| 对应分析 | [04-accuracy-contract.md](../04-accuracy-contract.md) A1 / A3 |

## 两个问题，建议拆成两个 PR

### A1 · int64 输出被降级成 F32

`src/package-files.ts`：

```ts
function cppDtype(dtype) {
  if (f16) return { cpp: 'half', ... }
  if (bf16) return { cpp: 'bfloat16_t', ... }
  return { cpp: 'float', enumerator: 'DType::F32' }   // int32 / int64 / 其它全落这里
}
```

后果：
1. int64 输出只分配 `elements * 4` 字节，按 float 读回比较 → **一个正确实现会被判错**；
2. 本次 kernel 只能把 index 当 float 写回（**为评测改语义**），原样提交 cannbench 会失败；
3. `maxAbsErrForDtype('int64')` 落到 `1e-3` 兜底 —— 编号差 0.0009 也算过。

**要做**：补 `int64_t/I64`、`int32/I32` 的 store/load/golden 分支；
整数 dtype 容差 = 0（bitwise）。
**如果做不完**：至少让 `build_test_package` 在「输出 dtype ∉ {f16,bf16,f32}」时**显式拒绝**，
不要静默降级 —— 静默降级比报错危险得多。

### A3 · 输入含大量并列值，与「首个最大值」契约冲突

契约输入生成：

```cpp
return -2.0f + 4.0f * (hashed % 1000u) / 999.0f;   // 16.7M 元素只有 1000 个取值
```

`[2048,2048]` 逐行 argmax：每行 2048 元素、1000 个取值 → **最大值几乎必然并列**。

cannbench 自己已经改了 `proto.yaml`：ArgMax 用 `compare: false` + `index_gather`
（校验 `input.gather(dim, indices) == input.amax(dim)`，不比并列顺序），
理由是「并列时 argmax 下标非确定，逐元素比对会把正确实现判失败」。

**要做**（二选一，建议都做）：
1. `pattern_value` 改成连续分布，让默认用例无并列；
2. `spec` 增加 `accuracyMode: 'elementwise' | 'index-check'`，SortSelect 类走 index-check：
   golden 返回 `bool verify(index, ...)`，由 golden 判断「指向的值是否等于 amax」。

## 测试

```ts
// 1) 渲染出的 main.cpp 对 int64 输出使用 8 字节且 DType::I64
// 2) 非 {f16,bf16,f32} 且未实现时，build_test_package 报错而不是降级
// 3) accuracyMode='index-check' 时 golden 走 verify 分支
// 4) 连续分布输入下，2048 行里并列行数为 0
```

## 验收（真机）

- [ ] 用 int64 输出 + 连续分布 + index-check 跑一次 ArgMax，`badCount = 0`
- [ ] 故意把 kernel 改成取「最后一个并列位置」→ **仍然 pass**（说明 index-check 生效）
- [ ] 故意返回错误 index → **fail**（说明不是放水）

## 注意

本次报告的 `maxRelativeError: 0` **不能**作为正确性证据：
它是在「index 以 float 存储 + 大量并列值 + 模型自写 golden」三个条件下得到的。
做完这个 ticket 之前，任何 `pass` 都要打个问号。
