# T-005 · 停滞判据 + 预算不可被清零

| 项 | 值 |
|---|---|
| 优先级 | P1 |
| 预估 | 2~3 h |
| 依赖 | T-000（代码已在保留分支里） |
| 需要真机 | 否 |
| 对应分析 | [01-loop-boundary.md](../01-loop-boundary.md) §5、[08-fix-plan.md](../08-fix-plan.md) 0.5 / 0.6 |

## 这两件事**代码已经写好了**，本 ticket 是「验证 + 补测 + 收尾」

代码位置（`origin/preserve/2026-11-06-argmax-run` 分支，或 T-000 拆分后的提交）：

| 改动 | 文件 |
|---|---|
| `recentKernelTimeUs` 窗口、`isStalled()`、`stalled` 停机理由 | `src/policy.ts` |
| `condenseCompileLog()`（过滤 `-Wignored-attributes` 一类样板） | `src/policy.ts` |
| 注入块增加「还差 N 倍 / 最近 3 轮 / 目标被放宽」提示 | `src/policy.ts` |
| `submit_spec` 同算子继承计数、可选 `reset:true`、记录 `targetRelaxedUs` | `src/generator.ts` |
| `stallRounds/stallGain/stallGap` 配置与 `stalled` 文案 | `src/eval.ts`、`src/loop.ts` |
| `bottleneck` 只在比率 > 0 时给结论 | `remote/runner.py`（属 T-007，这里不重复） |
| 8 条单测 | `tests/policy.test.ts` |

## 判据定义（避免二次理解偏差）

```
stalled := 最近 (stallRounds+1) 轮中，每一轮的相对增益 < stallGain
           且 achieved / target >= stallGap

默认: stallRounds=2, stallGain=0.03, stallGap=1.5
```

关键点：**两个条件同时成立才停**。
只用「增益小」会把真正在收敛的 kernel 提前停掉；
只用「差得远」会把还在快速改善的 kernel 停掉。

本次数据对照：
- `350 → 349 → 348`（每轮 0.3%）、目标差 2.9× → **stalled** ✅
- `398 → 374 → 350`（每轮约 6%）→ 不停（预算兜底）✅

## 本 ticket 要补的事

1. **重跑并扩散测试**：现有 18 条 policy 单测只覆盖了 `policy.ts`；
   请补 `generator.ts` 的预算继承测试：
   ```ts
   // a) 同 operator 重新 submit_spec → validIterations 不清零
   // b) reset: true → 清零
   // c) 不同 operator → 清零
   // d) target_us 变大 → 返回 relaxedTargetFromUs 且 state.targetRelaxedUs 被记录
   ```
2. **确认 loop 侧真的用上了这三个新配置**（T-000 说过 `lib/loop.js` 曾是旧的）。
3. **评估 `stallGain=0.03` 是否合适**：建议拿历史数据（782/781/668/398/374/350）在测试里跑一遍，
   把结论写进 PR。
4. **修一处诚实的描述**：`policy.ts` 里 `enhancementBlock` 的「还差 N 倍」用的是最近一次报告，
   不是最佳值。如果要对比「最佳 vs 目标」，请明确加一列，不要混用。

## 验收

- [ ] `generator` 的 4 条新测试
- [ ] 用本次真实数据序列跑 `stopReason`，返回 `stalled`，且 `shouldSteer === false`
- [ ] 手工确认：`stalled` 时 `run_evaluation` 的文案包含「还差 N 倍」与三个可选出路
      （换算法 / 显式放宽目标 / 停止任务）

## 注意（重要）

`stalled` **不是根治**。它只是让「不可达」变得可停止。
真正的根因见 [T-001](T-001-loop-session-affinity.md) / [T-002](T-002-loop-driven-by-eval.md)，
这三条都要做，缺一条都还会出现「空转注入」。
