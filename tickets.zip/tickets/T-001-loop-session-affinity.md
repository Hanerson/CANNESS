# T-001 · 循环加会话归属，消除跨会话串味

> ## ✅ 已完成（2026-11-06）
>
> - `TaskState` 新增 `ownerSessionId`；`run_evaluation` 从 `exec.agent.session.id` 认领任务，
>   并在每次写报告时刷新归属（后一次调用会接管，不会出现两个会话都以为自己拥有）。
> - `policy.ownsSession()`：**没有归属的旧 state 一律不驱动**（不猜测）。
> - `loop.ts` 的两个监听器都先过归属判定；`submit_spec` 换代时保留归属。
> - 单测 3 条覆盖（归属匹配 / 归属不匹配 / 无归属），见 `tests/plugins.test.ts`。
> - 详细过程见 `reports/T-001-deepseek.md`。

| 项 | 值 |
|---|---|
| 优先级 | **P0**（本次事故根因之一） |
| 预估 | 4~6 h |
| 依赖 | T-000 |
| 需要真机 | 否 |
| 对应分析 | [01-loop-boundary.md](../01-loop-boundary.md) §2 第 1 点、§6 P0-1 |

## 现象（实测）

| 会话 | 注入次数 | 说明 |
|---|---|---|
| 跑 ArgMax 的那个会话 | 232 | 任务本体 |
| **另一个做插件开发的会话** | **40** | 从没跑过 ArgMax，照样被催「请修改四层代码」 |

## 根因

1. `canness-workspace/.canness/state.json` **只有一份**，任何会话读到的都是同一份「上次评测」；
2. `canness-loop` 监听的 `agent/pre-step` 与 `agent/turn-stopping` 是**全局**的；
3. `agent/pre-step` 的回调参数本来就带 `agent`，实现里却是 `async (_payload, next)`——
   直接丢弃了这个身份。

```ts
// plugin/src/loop.ts（当前）
ctx.on('agent/pre-step', async (_payload, next) => {   // ← agent 在这里，被忽略了
  const decision = await next()
  ...
  if (!shouldSteer(state, config)) return decision
```

## 要做的事

1. `state.json` 增加 `ownerSessionId?: string`；
2. `run_evaluation` 执行时把当前 `agent.session.id` 写进去
   （`ToolRunContext` 有 `agent?: Agent`，见 `@deepseek-ai/dsh-tools` 的 `ToolExecutionInput`）；
3. `loop` 的两个监听器都先判断归属：

```ts
const owner = state.ownerSessionId
// 无归属（旧状态文件）或归属不是本会话 → 不 steer、不注入
if (owner === undefined || owner !== agent.session.id) return decision
```

4. 状态文件里另存一份轻量摘要（`generationId` / `status` / `ownerSessionId`），
   让「别的会话在用这个 workspace」这件事可被观测，而不是静默。
5. **兼容旧状态**：没有 `ownerSessionId` 的旧文件不要猜，**默认不驱动**，
   并在日志里提示一次「未认领的任务，需在本会话重新 run_evaluation 才继续」。

## 测试要求（务必写）

用假的 `state.json` + 两个不同的 `agent.session.id`：

```ts
// a) 归属匹配 → 会 steer
// b) 归属不匹配 → 不 steer、不注入
// c) 无 ownerSessionId（旧文件） → 不 steer
```

参考现有测试骨架：`plugin/tests/plugins.test.ts` 里的 `fakeCtx()` 记录了 `listeners`，
可以直接触发 `agent/pre-step` / `agent/turn-stopping` 验证行为。

## 验收

- [ ] 单测覆盖上面 (a)(b)(c)
- [ ] 手工：伪造 `perf_fail` 状态的 state.json 并把 `ownerSessionId` 设为会话 A，
      在会话 B 里什么都不做 5 分钟 → **0 次注入**
- [ ] 会话 A 里仍能正常被驱动（说明没把功能改死）

## 注意

- 这是**行为变更**：升级后，老任务的 `state.json` 会让循环不再自动续跑。这是有意的，
  请在 PR 描述里写清楚，并在 CHANGELOG 标注「需要重新 run_evaluation 认领」。
- 不要把 `ownerSessionId` 做成「自动取最近一次调用的会话」，那会退化成现在的问题。
