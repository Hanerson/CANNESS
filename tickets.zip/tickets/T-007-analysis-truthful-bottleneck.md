# T-007 · 瓶颈判据诚实化 + 带宽 / roofline 字段

| 项 | 值 |
|---|---|
| 优先级 | P1 |
| 预估 | 4 h |
| 依赖 | 无 |
| 需要真机 | 建议（一次 profile 即可） |
| 对应分析 | [03-eval-integrity.md](../03-eval-integrity.md) D3 / D4 |

## 现象

出事时 `state.json` 的 analysis：

```json
{ "bottleneck": "cube",
  "summary": "... aic_mac_ratio 0.0, aic_mte2_ratio 0.0, aic_scalar_ratio 0.0.",
  "op": { "taskType": "AI_CORE", "aicoreTimeUs": 0, "blockDim": null,
          "aicMacRatio": 0, "aicMte2Ratio": 0, "aicScalarRatio": 0, "cubeUtilizationPct": 0 } }
```

ArgMax 只用 Vector 指令，`mac`（Cube）为 0 是对的；但 `mte2` 和 `scalar` **不可能**同时为 0
（搬了 16 MiB、做了大量比较）。真相：这三列存在但被 0 填充（该 CANN 默认档位没采集）。

旧代码把三个 0 当数据：`max({mac:0, mte2:0, scalar:0})` 取第一个键 → 判成 `cube`。
**一个纯向量算子被标成 Cube 受限**，优化方向直接被带偏。

## 已完成（在保留分支里）

`remote/runner.py` 的 `build_profile()`：

- 三个比率改为**跨行取均值**（原来只取 `rows[0]`，与时长口径不一致）；
- 只有 `> 0` 的比率参与 `bottleneck`；
- 全 0 → `bottleneck = 'unknown'`，summary 追加
  「aic-metrics were not collected for this run」。

## 本 ticket 要补的事

1. **补测**：`tests/` 里加一条用「全 0 比率」的 CSV 断言 `bottleneck === 'unknown'`，
   再用一条「mte2=0.71」的 CSV 断言 `bottleneck === 'memory'`；
2. **采集 AIV 指标**：`--aic-metrics=PipeUtilization`（`plugin/knowledge_base/AscendC_Compile_Run.md`
   的 msprof 段已验证可行），并优先用 `aiv_*` 列；同时注意 `taskType` 过滤；
3. **新增字段**（`src/analysis.ts` + `src/eval.ts` 的 output schema + `runner.py`）：

   | 字段 | 语义 |
   |---|---|
   | `achievedBandwidthGBps` | `bytes / duration`，bytes 由 spec 的输入输出 shape/dtype 推出（需新增推导函数） |
   | `rooflineUs` | `bytes / peakBw`，`peakBw` 由 spec 的 `target_platform.chip` 查表 |

   本次参考值：16 MiB / 349.627µs ≈ **48 GB/s**，910B HBM ≈ 1.6 TB/s → 约 3%。

4. 报告里输出「实测 / 基线 / 目标」三段，没有基线时明确写 `baseline: null`。

## 验收

- [ ] 两条新单元测试（全 0 → unknown；有值 → 正确归类）
- [ ] 真机一次 profile 后，报告里 `achievedBandwidthGBps` 与手算一致（误差 < 5%）
- [ ] 报告里不再出现「AIV 算子被判成 cube」

## 注意

`peakBw` 查表的数值请注明来源与适用芯片；查不到时输出 `null` 而不是猜。
