# T-002 · 循环只在本轮真跑过评测时驱动

> ## ✅ 已完成（2026-11-06）
>
> - `TaskState` 新增 `pendingSteer`：只有 `run_evaluation` 真正写出报告时才置 `true`，
>   `submit_spec` 换代时置 `false`。
> - `loop.ts` 的 `pre-step` 与 `turn-stopping` 都要求 `pendingSteer === true`，
>   并在**注入或 steer 之前**把它消费掉——一份报告只换一次续轮。
> - 早退路径（host 为空、凭据缺失、隧道断开、连接失败、策略停机）不置 `pendingSteer`，
>   所以失败不会自我驱动。
> - 单测 3 条覆盖（欠一次 / 已消费 / 未欠），另外验证了「别的会话不会消费掉本会话的欠账」。
> - 详细过程见 `reports/T-002-deepseek.md`。

| 项 | 值 |
|---|---|
| 优先级 | **P0**（本次事故的直接原因） |
| 预估 | 4~6 h |
| 依赖 | T-000（可与 T-001 并行开发，合并时两者都要） |
| 需要真机 | 否 |
| 对应分析 | [01-loop-boundary.md](../01-loop-boundary.md) §2 自持回路、§6 P0-2 |

## 现象

注入间隔中位数 **5.3 秒**，而一次评测要 **12~14 秒**。
最后 15 分钟（16:01 → 16:16）**没有任何新评测**，注入照样每 5 秒一次。

结论：驱动节奏由**模型回合**决定，与评测无关。

## 根因（`plugin/src/loop.ts`）

```ts
ctx.on('agent/turn-stopping', ({ agent }) => {
  const state = loadState(path)
  if (!shouldSteer(state, config)) return   // 只判断「上次报告不是 pass」
  agent.steer(notice(enhancementBlock(state)))   // 无去重、无条件
})
```

只要磁盘上最后一份报告不是 `pass`，**每一轮结束时**都会 steer 出一轮新的。
模型这一轮如果只是在读文档、改插件、解释现象，也会被当成「该继续评测」。

## 要做的事（推荐方案：pendingSteer 许可制）

1. `state.json` 增加 `pendingSteer?: boolean`，默认 `false`；
2. **`run_evaluation` 真正写出新报告时**（含 compile_fail / perf_fail / error）
   才置 `pendingSteer = true`；
3. `loop` 的 `turn-stopping` 只有在 `pendingSteer === true` 时才 steer，
   steer 后**立即清零**（消费一次）；
4. `pre-step` 的注入同样受 `pendingSteer` 约束，避免「steer 后又被塞第二条」；
5. 保留现有「同轮去重」（`already` 判断）作为第二道保险。

伪代码：

```ts
// eval.ts：成功写入报告之后
saveState(path, { ...next, pendingSteer: true })

// loop.ts
ctx.on('agent/turn-stopping', ({ agent }) => {
  const state = loadState(path)
  if (state.pendingSteer !== true) return
  if (!shouldSteer(state, config)) return
  saveState(path, { ...state, pendingSteer: false })   // 先消费，再 steer
  agent.steer(notice(enhancementBlock(state, config)))
})
```

## 测试要求

```ts
// a) pendingSteer=true 且报告非 pass → steer 一次，且 pendingSteer 变 false
// b) 再触发一次 turn-stopping → 不再 steer（已消费）
// c) pendingSteer=false（本轮没评测）→ 不 steer，即使 lastReport 是 perf_fail
// d) 新一轮 run_evaluation 写报告 → pendingSteer 重新变 true
```

## 验收

- [ ] 上述 4 条单测
- [ ] 手工：伪造 `perf_fail` + `pendingSteer=false` 的 state，起会话不发言 10 分钟 → **0 次注入**
- [ ] 手工：跑一次真实 `run_evaluation`（远端不可用也行，`status: error` 也算）→ 恰好被驱动一次

## 注意

- `pendingSteer` 必须是**持久化**的，否则进程重启后回路会复活（这正是现在重启也没用的原因之一）。
- 与 T-003 限流叠加使用；两者不冲突。
