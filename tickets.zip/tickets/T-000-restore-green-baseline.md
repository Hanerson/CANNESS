# T-000 · 止血基线：重建 lib、把已验证改动拆成干净提交

> ## ✅ 已完成（2026-11-06）
>
> - 4 个语义提交：`187850d` 契约（002/003/006/013）、`eeac773` runner（004/009）、
>   `a72c078` policy+知识库（016 缓解 + ArgMax.md）、`72c93e0` .gitignore。
> - `lib/` 已重建，四个 marker 全部命中（`spec.launch`、`policy.isStalled`、
>   `generator.carriedOver`、`eval.stallRounds`），另加 `loop.stallRounds`、`package-files.(GM_ADDR)`。
> - `pnpm test`：**152 通过 / 7 失败**，失败全部是 `eval-runner.test.ts` 的既有 Windows 问题（T-013），
>   与本批改动无关（stash 后同样 7 条）。
> - `plugin/remote/__pycache__/` 已删除并加入 `.gitignore`。
> - 详细过程与验证输出见 `reports/T-000-deepseek.md`。

| 项 | 值 |
|---|---|
| 优先级 | P0（**所有人之前先做这个**） |
| 预估 | 2~3 h |
| 依赖 | 无 |
| 需要真机 | 否 |
| 对应分析 | [08-fix-plan.md](../08-fix-plan.md) 第 0.0 项、[07-ops-config.md](../07-ops-config.md) O2 |

## 背景

现在仓库处于一个**会骗人**的状态：

- `main`（`dd9328d`）的构建契约仍渲染 `static_cast<GM_ADDR>`，必然编译失败；
- 一批修复只存在于本地工作区，`git status` 有 13 项未提交；
- 更麻烦的是 `lib/`（dsh 真正加载的产物）只重建了一部分。

## 现状证据（照原样核对）

```
$ git status --short
 M plugin/remote/runner.py
 M plugin/src/eval.ts
 M plugin/src/generator.ts
 M plugin/src/loop.ts
 M plugin/src/package-files.ts
 M plugin/src/policy.ts
 M plugin/src/spec.ts
 M plugin/templates/build-contract/build.sh
 M plugin/templates/build-contract/canness_tiling.h
 M plugin/templates/build-contract/main.cpp
 M plugin/tests/policy.test.ts
?? plugin/knowledge_base/ArgMax.md
?? plugin/remote/__pycache__/
```

`src` 与 `lib` 的新旧对比（修复后请确保全部重建）：

| 模块 | src 有 | lib 有 | 说明 |
|---|---|---|---|
| `package-files` | `(GM_ADDR)` | ✅ | 运行期生效 |
| `spec` | `launch` | ❌ | 旧产物 |
| `policy` | `isStalled` | ❌ | 旧产物 |
| `generator` | `carriedOver` | ❌ | 旧产物 |
| `eval` | `stallRounds` | ❌ | 旧产物 |
| `loop` | `stallRounds` | ❌ | 旧产物 |

## 要做的事

1. **删掉 `plugin/remote/__pycache__/`**，并确认它在 `.gitignore` 里。
2. **`pnpm build`**，然后逐条核对四个 marker：
   ```powershell
   Select-String lib\spec.js -Pattern "launch"        # 必须命中
   Select-String lib\policy.js -Pattern "isStalled"   # 必须命中
   Select-String lib\generator.js -Pattern "carriedOver"
   Select-String lib\eval.js -Pattern "stallRounds"
   ```
3. **把改动拆成语义清晰的提交**（建议顺序）：
   - `fix(contract): render (GM_ADDR) casts instead of static_cast<GM_ADDR>`（issue 002）
   - `fix(contract): link with --allow-multiple-definition for the duplicated g_tilingKey`（issue 003；**注意**：T-011 会用更彻底的方式替换它）
   - `fix(runner): find the msprof CSV below PROF_*/`（issue 004）
   - `feat(spec): launch.block_dim and a workspace scratch region in the tiling buffer`（issue 006 / 013）
   - `fix(runner): report bottleneck only from aic ratios above zero`（issue 009）
   - `feat(policy): stall detection and budget carry-over on submit_spec`（issue 016 的部分缓解，**不是根治**，见 T-001/T-002）
   - `docs(kb): add ArgMax with the API semantics found by probing`
4. 每个提交后跑 `pnpm test`（除了 `eval-runner.test.ts` 的既有失败，见 T-013）。
5. 在 PR 描述里注明：**这批改动来自一次未验证的现场，标为「已本地验证单测」而不是「已真机验证」**。

## 验收

- [ ] `git status` 干净
- [ ] `pnpm build` 后四个 marker 全部命中，且 `git status` 仍干净（说明产物已入库或已被忽略——二选一，与现有约定一致）
- [ ] `main` 上 `grep "static_cast<GM_ADDR>" plugin/src plugin/lib` 无输出
- [ ] `pnpm test` 只剩 `eval-runner.test.ts` 的既有失败（且失败原因仍与 T-013 描述一致）

## 注意

- **不要**把 `preserve/2026-11-06-argmax-run` 整支合并。它混着「已验证」「未验证」「环境相关」三种状态，
  直接合会让问题更难拆。
- 如果你发现 `lib/` 本来就被 `.gitignore` 忽略（当前是这样），那么「产物要不要入库」是个约定问题：
  现在运行期加载的是磁盘上的 `lib/`，**任何人改完 src 都必须自己 build**。至少要把这句话写进
  `plugin/README.md`（见 T-014）。

## 完成后请填

- 实际拆成了几个提交、每个提交的 hash
- `pnpm test` 的实际结果（通过 / 失败数，失败是否是既有的那 7 条）
- 有没有发现我描述之外的问题
