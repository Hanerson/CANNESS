# T-006 · set_env.sh 三级探测 + 进 runRecord

| 项 | 值 |
|---|---|
| 优先级 | **P0**（唯一还挡着「干净镜像首轮能否编译」的问题） |
| 预估 | 3 h |
| 依赖 | 无（可与 T-000 并行） |
| 需要真机 | **是**（一次，只需首轮编译） |
| 对应分析 | [02-build-contract.md](../02-build-contract.md) C1、[07-ops-config.md](../07-ops-config.md) O1 |

## 现象

干净 CANNLab 镜像上首次 `run_evaluation`：

```
build.sh: bisheng not found; source set_env.sh before building
build.sh exited 127
```

## 根因

| 位置 | 默认值 | 问题 |
|---|---|---|
| `remote/runner.py` `--set-env` | `/usr/local/Ascend/ascend-toolkit/set_env.sh` | CANNLab 镜像把 toolkit 装在 `$HOME/Ascend/cann-9.0.0` |
| `templates/build-contract/build.sh` `CANN=` | `${ASCEND_TOOLKIT_HOME:-/usr/local/...}` | 同上 |

而且文件不存在时 `shell_env_prefix()` **静默跳过**，于是错误推迟到 `build.sh`，
报错信息还把责任推给用户（"source set_env.sh"）。

本次实测的镜像事实（供参考，2026-11-06）：

```
ASCEND_TOOLKIT_HOME=/home/developer/Ascend/cann-9.0.0
ls /home/developer/Ascend/  → ascend-toolkit  cann  cann-9.0.0  nnal
/usr/local/Ascend 下只有 driver
```

## 要做的事

1. `shell_env_prefix()` 按顺序探测，取第一个存在的：
   1. `$ASCEND_TOOLKIT_HOME/set_env.sh`
   2. `$HOME/Ascend/ascend-toolkit/set_env.sh`
   3. `$HOME/Ascend/cann-*/set_env.sh`（按版本号倒序）
   4. `/usr/local/Ascend/ascend-toolkit/set_env.sh`
   5. 命令行显式 `--set-env`（若给了且存在，优先级最高）
2. **选中的路径写进 `runRecord.params.setEnv`**；
3. **一个都没找到时不要静默**：在 `compile.log` 开头写
   `set_env.sh not found; searched: <列表>; PATH may lack bisheng`；
4. `canness-eval` 增加配置项 `setEnv`（默认空 = 自动探测），由 `runnerCommand()` 透传；
5. 顺带把 `device` / `runs` / `lock` 也暴露（O1 的其余部分，可选，别混进同一个 PR）。

## 测试

- 单元（不连远端）：用假的远端目录树（`tests/` 里已有 python 子进程测试骨架）
  验证探测顺序与「找不到时报错文案」；
- 真机（一次）：在一台**没建过软链**的 CANNLab 实例上跑首轮 `run_evaluation`。

## 验收

- [ ] 干净镜像首轮不再 `exit 127`
- [ ] `runRecord.params.setEnv` 有值，且指向实际存在的文件
- [ ] 故意把三处都改名 → `compile.log` 明确列出搜索过的路径

## 注意

本次事故是靠**宿主机建软链**绕过的（`ln -sfn /home/developer/Ascend/ascend-toolkit /usr/local/Ascend/ascend-toolkit`）。
如果你的测试实例还留着这个软链，**先删掉再测**，否则会假通过。
