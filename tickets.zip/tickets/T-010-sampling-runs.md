# T-010 · 多次采样与热身（`over 1 rows`）

| 项 | 值 |
|---|---|
| 优先级 | P1 |
| 预估 | 4 h |
| 依赖 | 无 |
| 需要真机 | **是** |
| 对应分析 | [03-eval-integrity.md](../03-eval-integrity.md) D2 |

## 现象

每次评测的 analysis 都是：

```
msprof op_summary: Task Duration avg 349.627us over 1 rows
```

`over 1 rows` —— 只有 **1 个采样点**，没有 min / avg / max，无法判断抖动；
而且首轮 `aclInit` / JIT / 页表都算进了这一次，数字偏高。

## 根因

```python
argv = [msprof, f'--application={executable} {args.runs}', f'--output={outdir}']
```

`msprof --application="<exe> 100"` 只是把 `100` 作为 argv 原样传给程序，
**msprof 自己不会重复执行**。而契约的 `main.cpp` 从不解析 argv：

```cpp
int main() { ... 一次 launch ... }
```

所以 `--runs 100` 是纯装饰。

## 要做的事

1. `templates/build-contract/main.cpp` 解析 `argv[1]` = 迭代次数：

```cpp
int runs = (argc > 1) ? std::atoi(argv[1]) : 1;
// warmup K 次（K = min(5, runs/5)）
// 计时 N 次，每次都 launch
// 只有最后一次做精度校验，CANNESS_RESULT 只打一次
```

2. `runner.py` 的 `--runs` 语义保持不变（拼进 `--application`），但默认值从 100 降到 **20**，
   并把实际生效值写进 `runRecord.params.runs`；
3. `analysis` 在行数 < 10 时输出 `low_sample_count` 警告（写进 summary 即可）；
4. 长耗时 kernel（> 1 ms）要能降采样：`runs = clamp(总预算 / 单次耗时)`，避免拖长评测时间。

## 测试 / 验收（真机）

- [ ] 一次 profile 后 `over N rows` 且 `N ≥ 20`
- [ ] 小 shape（µs 级）用例上，多次采样的均值与单次值差异可见（证明热身有效）
- [ ] `CANNESS_RESULT` 只出现一行（runner 只取最后一行，不要打乱解析）
- [ ] 评测耗时没有明显变长（目标 < 原 12~14 s 的 1.5 倍）

## 注意

改 `main.cpp` 属于模板改动 → **下一轮 `build_test_package` 立即生效**，不需要重启 dsh。
但记得同步跑一次精度回归（warmup 之后状态可能不同）。
